<div class="modal-content">
    <div class="modal-header">
        <h3 class="text-center pull-left">Pay Coach</h3>
        <button type="button" class="close pull-right" data-dismiss="modal">&times;</button>
    </div>
    <form action="{{ route('coach.pay') }}" method="POST">
        @csrf
        <input type="hidden" name="tutor_id" value="{{ $tutor->id }}">
        <div class="modal-body">
            <div class="form-group">
                <label class="font-weight-bold">Coach Name</label>
                <input type="text" class="form-control" name="coach_name" value="{{ $tutor->name }}" readonly>
            </div> 
            <div class="form-group">
                <label class="font-weight-bold">Payment</label>
                <input type="text" class="form-control numbers" name="payment" value="">
            </div> 
        </div>
        <div class="modal-footer">
            <button class="btn btn-success">Pay Coach</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
    </form>
</div>