<a style="float:right;" class="row p-0 m-0" href="{{ url('dashboard-home') }}">View All</a><br/>
@foreach($request_list as $item)
	<div>
		<h5 class="mt-2">{{ $date }}<span class="ml-4 text-muted" style="font-size: 12px;">{{ $item->start_time }}</span></h5>
		<h6 class="text-muted">
			{{ $item->student->name }}
			<a href="javascript:void(0);" data-id="{{ $item->id }}" class="start-zoom-session" style="float: right;">Start Session</a>
		</h6>

	</div><hr>
@endforeach
@if($request_list->count() == 0)
	<div style="border:2px solid #69d2b1;height: 30px;text-align: center;">
		No Class Yet, Take Rest
	</div>
@endif